package BaseClass;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LogIn {

	WebDriver dr;
	
	@FindBy(xpath="//*[@class='ico-login']")
	WebElement Login;
	
	@FindBy(xpath="//input[@id='Email']")
	WebElement email;
	
	@FindBy(xpath="//input[@id='Password']")
	WebElement password;
	
	@FindBy(xpath="//input[@value='Log in']")
	WebElement clk_login;
	

	
	
	public LogIn(WebDriver dr)
	{
		this.dr = dr;
		PageFactory.initElements(dr,this);
	}
	
	public void verify_login_link()
	{	
		 Login.click();
	}
	
	public void enter_eid(String usr)
	{
		email.sendKeys(usr);
	}
	
	public void enter_pass(String pass)
	{
		password.sendKeys(pass);
	}
	public void clck_log_in()
	{
		clk_login.click();
	}
	public String get_title()
	{
		//String title = dr.getTitle();
		Login.click();
		return dr.getTitle();
		//return title;
	}
}
