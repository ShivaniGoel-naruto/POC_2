package BaseClass;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Myaccount {

	@FindBy(xpath="//a[@class='ico-logout']")
	WebElement logout;
	
	@FindBy(xpath="//a[@class='account']")
	WebElement profile;
	
	WebDriver dr;

	/*
	 * public Myaccount(WebDriver dr) {
	 * 
	 * this.dr = dr; PageFactory.initElements(dr,this); }
	 */
	public Myaccount(WebDriver dr) {
		// TODO Auto-generated constructor stub
		this.dr = dr;
		PageFactory.initElements(dr,this);
	}
	public void LogOut()
	{
		logout.click();
	}
	
	public String profile_info()
	{
		return profile.getText();
	}
}
