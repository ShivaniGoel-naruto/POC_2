package BaseClass;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage {
	
	WebDriver dr;
	
	@FindBy(xpath="//a[@href='/register']")
	WebElement Register;
	
	@FindBy(xpath="//*[@class='ico-login']")
	WebElement Login;
	
//	@FindBy(xpath="//a[@href=\"/login\"]")
//	WebElement Login;
	
	public HomePage(WebDriver dr)
	{
		this.dr = dr;
		PageFactory.initElements(dr,this);
	}
	
	public String verify_login_link()
	{	System.out.print("sdfsd");
		System.out.print(Login.getText());
		return Login.getText();
	}
	
	public String verify_register_link()
	{
		return Register.getText();
	}
	
	public String get_title()
	{
		//String title = dr.getTitle();
		return dr.getTitle();
		//return title;
	}
	
	
	
	
	

}
