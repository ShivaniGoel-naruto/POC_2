package utilities;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class read_write {

	String[][] arr = new String[2][3];
	String email,password,ev;
	public String[][] readExcel()
	{
		try {
			File f = new File("D:\\POC_2.xlsx");
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet("Sheet1");
			System.out.println("read_write.readExcel()");
			for(int i=1,j=0;i<=2;i++)
			{
				//System.out.println("1");
				XSSFRow row =sh.getRow(i);

				System.out.println("3");
				XSSFCell cell = row.getCell(0);
				email = cell.getStringCellValue();
				arr[i-1][j++]=email;

				System.out.println("45");
				
				 cell = row.getCell(1);
				password =  cell.getStringCellValue();
				arr[i-1][j++]=password;
				System.out.println("45");
				
				 cell = row.getCell(2);
				ev = cell.getStringCellValue();
				arr[i-1][j++]=ev;
				
				j=0;
				
			}
			
			for(int i=0;i<2;i++)
			{
			
				for(int j=0;j<3;j++)
					System.out.println(arr[i][j]);
			}
		}
		catch(Exception e)
		{
			
		}
		return arr;
	}
	
	/*
	 * public static void main(String arr[]) { read_write rw= new read_write();
	 * rw.readExcel(); }
	 */
}
