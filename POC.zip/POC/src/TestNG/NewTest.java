package TestNG;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import BaseClass.HomePage;
import BaseClass.LogIn;

public class NewTest {
	WebDriver dr;
	HomePage hp;
	LogIn lin;
	Logger log;
	String login, reg,til,til2;
  @BeforeClass
  public void launchBrowser() {
	  System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		 dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/");
		 log = Logger.getLogger("devpinoyLogger");
		  log.info("Test case executed launchBrowser");
  }
  @AfterClass
  public void close()
  {
	  dr.close();
  }
 
  @Test(priority=2)
  public void test_login_link()
  {
	  hp = new HomePage(dr);
	 login = hp.verify_login_link();
	 System.out.println("ehetr"+login);
	 SoftAssert as = new  SoftAssert();
	 as.assertEquals(login,"Log in");
	 as.assertAll();
	 log = Logger.getLogger("devpinoyLogger");
	  log.info("Test case executed test_login_link");
  }
  
  @Test(priority=4)
  public void test_register_link()
  {
	 reg = hp.verify_register_link();
	 System.out.println("ehetr"+reg);
	 SoftAssert as = new  SoftAssert();
	 as.assertEquals(reg,"Register");
	 as.assertAll();
	 log = Logger.getLogger("devpinoyLogger");
	  log.info("Test case executed test_register_link");
  }
  
  @Test(priority=6)
  public void test_title()
  {
	  til = hp.get_title();
	  System.out.println("ehetr"+til);
		 SoftAssert as = new  SoftAssert();
		 as.assertEquals(til,"Demo Web Shop");
		 as.assertAll();
		 log = Logger.getLogger("devpinoyLogger");
		  log.info("Test case executed test_title");
  }
  
  @Test(priority=8)
  public void test_title_2()
  {
	    lin=new LogIn(dr);
	    til = lin.get_title();
	    System.out.println("ehetr"+til);
		 SoftAssert as = new  SoftAssert();
		 as.assertEquals(til,"Demo Web Shop. Login");
		 as.assertAll();
		 log = Logger.getLogger("devpinoyLogger");
		  log.info("Test case executed test_title_2");
  }
  
}
