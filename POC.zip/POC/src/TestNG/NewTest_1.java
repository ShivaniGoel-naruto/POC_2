package TestNG;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import BaseClass.LogIn;
import BaseClass.Myaccount;
import utilities.read_write;

public class NewTest_1 //extends NewTest
{
	WebDriver dr;
	read_write wr;
	LogIn sigin;
	Myaccount ma;
	String login_testdata[][] ;
	Myaccount acc;
	String av;
	Logger log;
 
	@BeforeClass
	 public void launchBrowser() {
		  System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
			 dr = new ChromeDriver();
			dr.get("http://demowebshop.tricentis.com/");
			 log = Logger.getLogger("devpinoyLogger");
			  log.info("Test case executed launchBrowser");
	  }
	
	@Test(dataProvider="logindata",priority=9)
	public void test_login(String eid, String pwd, String ev)
	{
		sigin = new LogIn(dr);
		sigin.verify_login_link();
		sigin.enter_eid(eid);
		sigin.enter_pass(pwd);
		sigin.clck_log_in();
		
		ma=new Myaccount(dr);
		av = ma.profile_info();
		verify(av,ev);
		ma.LogOut();
		 log = Logger.getLogger("devpinoyLogger");
		  log.info("Test case executed test_login");
		
	}
	public void verify(String av, String ev)
	{
		Assert.assertEquals(av,ev);
	}
	
	@DataProvider(name="logindata")
  public String[][] getData() {
		get_excel();
	return login_testdata;
	
	    
  }
	
	public void get_excel()
	{
		wr = new read_write();
		
		login_testdata= wr.readExcel();
		
	}
	
	@AfterClass
	public void close()
	{
		dr.close();
	}
}
